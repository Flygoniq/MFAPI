CREATE TABLE "user"(
  user_id character varying(255) NOT NULL,
  password character varying(255) NOT NULL,
  nickname character varying(255),
  comment character varying(255)
);